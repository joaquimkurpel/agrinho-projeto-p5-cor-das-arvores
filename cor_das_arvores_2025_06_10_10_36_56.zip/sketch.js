let plants = [];
let season = "spring";
let seasonChangeTimer = 0;

function setup() {
  createCanvas(800, 600);
}

function draw() {
  // Atualiza o tempo e a estação
  updateSeason();

  // Desenha o fundo (de acordo com a estação)
  drawBackground();

  // Desenha as plantas e faz elas crescerem
  for (let plant of plants) {
    plant.display();
    plant.grow();
  }

  // Exibe o texto da estação
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text(season.charAt(0).toUpperCase() + season.slice(1), width / 2, 50);
}

// Função de interação (planta uma semente ao clicar)
function mousePressed() {
  let newPlant = new Plant(mouseX, mouseY);
  plants.push(newPlant);
}

// Função para atualizar a estação
function updateSeason() {
  seasonChangeTimer++;

  if (seasonChangeTimer >= 500) { // Troca de estação a cada 500 frames
    seasonChangeTimer = 0;
    
    if (season === "spring") {
      season = "summer";
    } else if (season === "summer") {
      season = "autumn";
    } else if (season === "autumn") {
      season = "winter";
    } else if (season === "winter") {
      season = "spring";
    }
  }
}

// Função para desenhar o fundo de acordo com a estação
function drawBackground() {
  if (season === "spring") {
    background(135, 206, 235); // Céu azul da primavera
  } else if (season === "summer") {
    background(255, 223, 0); // Céu quente do verão
  } else if (season === "autumn") {
    background(255, 165, 0); // Céu alaranjado do outono
  } else if (season === "winter") {
    background(173, 216, 230); // Céu claro do inverno com neve
  }
  
  // Desenha o solo
  fill(34, 139, 34);
  rect(0, height - 100, width, 100); // Solo verde
}

// Classe para a planta
class Plant {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 10;
    this.growthRate = 0.1;
    this.health = 100;
    this.color = color(34, 139, 34); // Cor da planta (verde)
  }

  display() {
    // Desenha o tronco da planta
    fill(139, 69, 19);
    rect(this.x - 5, this.y - this.size, 10, this.size);

    // Desenha as folhas (folhagem)
    fill(this.color);
    ellipse(this.x, this.y - this.size - 10, this.size * 1.5, this.size);
  }

  grow() {
    // Crescimento da planta ao longo do tempo
    if (this.size < 50) {
      this.size += this.growthRate;
    }

    // A planta muda de cor conforme a estação
    if (season === "spring") {
      this.color = color(34, 139, 34); // Verde claro
    } else if (season === "summer") {
      this.color = color(0, 128, 0); // Verde mais forte
    } else if (season === "autumn") {
      this.color = color(255, 69, 0); // Folhas laranja
    } else if (season === "winter") {
      this.color = color(169, 169, 169); // Folhas secas (cinza)
    }
  }
}
